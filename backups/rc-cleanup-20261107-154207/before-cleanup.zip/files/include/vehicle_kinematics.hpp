#pragma once
#include <math.h>
#include <stdint.h>

namespace vehicle {
constexpr float pi = 3.14159265358979323846f;
constexpr float deg = pi / 180.0f;
constexpr float velocity_epsilon = 0.001f; // 1 mm/s; hold direction at rest
inline float clamp(float x, float lo, float hi) { return fminf(hi, fmaxf(lo, x)); }
enum class DriveMode { SKID_STEER, INDEPENDENT_STEERING };
enum class TurnInput { YAW_RATE, CURVATURE };
struct VehicleCommand {
    float linear_velocity, angular_velocity, curvature;
    TurnInput turn_input;
    // Existing ROS callers retain (m/s, rad/s). RC retains curvature at v=0.
    VehicleCommand(float v, float w)
        : linear_velocity(v), angular_velocity(w), curvature(0), turn_input(TurnInput::YAW_RATE) {}
    static VehicleCommand with_curvature(float v, float inverse_radius) {
        VehicleCommand cmd(v, 0);
        cmd.curvature = inverse_radius;
        cmd.turn_input = TurnInput::CURVATURE;
        return cmd;
    }
};
struct Geometry {
    float wheelbase = 0.420f;
    float front_track = 0.439f;
    float rear_track = 0.439f;
    float radius = 0.065f;
    float skid_track = 0.485f; // Preserve physically tested legacy mixing.
};
struct WheelTargets {
    float angle[2] = {}; // FL, FR, radians, commanded (never measured)
    float rpm[4] = {};   // FL, FR, RL, RR; rolling signs, existing CAN polarity
    bool feasible = true;
};
inline float speed_to_rpm(float speed, const Geometry &g) {
    return speed * 60.0f / (2.0f * pi * g.radius);
}
// Signed inner-wheel angle -> rear-axle-center curvature (1/m).
// The outer wheel gets its own Ackermann angle, not the same servo angle.
inline float curvature_from_inner_angle(float angle, const Geometry &g) {
    const float tangent = tanf(angle);
    return tangent / (g.wheelbase + g.front_track * 0.5f * fabsf(tangent));
}
// Reject the entire command. Never clamp one angle and retain inconsistent RPMs.
inline WheelTargets inverse(VehicleCommand cmd, DriveMode mode, const Geometry &g,
                            const float previous[2], const float minimum[2],
                            const float maximum[2]) {
    WheelTargets out;
    for (int i = 0; i < 2; ++i) out.angle[i] = previous[i];
    const bool curvature_input = cmd.turn_input == TurnInput::CURVATURE;
    const float v = cmd.linear_velocity;
    const float turn = curvature_input ? cmd.curvature : cmd.angular_velocity;
    if (!isfinite(v) || !isfinite(turn) || fabsf(v) > 2.0f ||
        (!curvature_input && fabsf(turn) > 5.0f)) {
        out.feasible = false;
        return out;
    }
    const float w = curvature_input ? v * turn : turn;
    if (mode == DriveMode::SKID_STEER) {
        out.angle[0] = out.angle[1] = 0.0f;
        out.rpm[0] = out.rpm[2] = speed_to_rpm(v - w*g.skid_track/2, g);
        out.rpm[1] = out.rpm[3] = speed_to_rpm(v + w*g.skid_track/2, g);
        return out;
    }
    for (int i = 0; i < 2; ++i) {
        // For curvature input, solve a unit forward path first. Multiplication
        // by signed v changes wheel speed only, so steering survives stop/reverse.
        const float path_v = curvature_input ? 1.0f : v;
        const float path_w = curvature_input ? turn : w;
        const float vx = path_v - path_w * (i == 0 ? 1 : -1) * g.front_track / 2;
        const float vy = path_w * g.wheelbase;
        const float speed = hypotf(vx, vy);
        if (speed <= velocity_epsilon) continue;
        float angle = atan2f(vy, vx);
        float sign = 1;
        if (angle > pi/2) { angle -= pi; sign = -1; }
        if (angle < -pi/2) { angle += pi; sign = -1; }
        // Allow only floating-point roundoff at an exactly commanded endpoint.
        if (angle < minimum[i] - 1e-6f || angle > maximum[i] + 1e-6f) out.feasible = false;
        out.angle[i] = clamp(angle, minimum[i], maximum[i]);
        out.rpm[i] = speed_to_rpm(sign * speed * (curvature_input ? v : 1.0f), g);
    }
    out.rpm[2] = speed_to_rpm(v - w*g.rear_track/2, g);
    out.rpm[3] = speed_to_rpm(v + w*g.rear_track/2, g);
    if (!out.feasible) {
        for (int i=0; i<4; ++i) out.rpm[i] = 0;
        for (int i=0; i<2; ++i) out.angle[i] = previous[i];
    }
    return out;
}
} // namespace vehicle
